# ShopDash - Complete Shopping Dashboard

A modern, responsive shopping dashboard built with React.js, Node.js, and MongoDB with Razorpay payment integration.

## Features

- **Dashboard Layout**: Modern sidebar navigation with responsive design
- **Product Display**: Beautiful product cards with images, prices, and descriptions
- **Shopping Cart**: Add/remove items, quantity management
- **Payment Integration**: Razorpay payment gateway for secure transactions
- **Order Management**: Complete order processing and confirmation
- **Real-time Updates**: Toast notifications for user feedback

## Tech Stack

### Frontend
- React.js (JavaScript)
- Tailwind CSS
- Axios for API calls
- React Hot Toast for notifications
- Lucide React for icons

### Backend
- Node.js + Express.js
- MongoDB + Mongoose
- Razorpay SDK
- CORS enabled
- Environment-based configuration

## Getting Started

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local or Atlas)
- Razorpay account for payment processing

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd shopdash
   ```

2. **Frontend Setup**
   ```bash
   npm install
   npm run dev
   ```

3. **Backend Setup**
   ```bash
   cd backend
   npm install
   ```

4. **Environment Configuration**
   Create a `.env` file in the backend directory:
   ```env
   PORT=5000
   MONGODB_URI=mongodb://localhost:27017/shopdash
   RAZORPAY_KEY_ID=your_razorpay_key_id
   RAZORPAY_KEY_SECRET=your_razorpay_key_secret
   ```

5. **Start Backend Server**
   ```bash
   npm start
   # or for development
   npm run dev
   ```

### Razorpay Setup

1. Create a Razorpay account at https://razorpay.com
2. Get your API keys from the dashboard
3. Replace the keys in:
   - Backend `.env` file
   - Frontend `App.jsx` (RAZORPAY_KEY_ID)

## API Endpoints

### Products
- `GET /api/products` - Fetch all products
- `POST /api/products` - Add new product (admin)

### Orders
- `POST /api/order` - Create new order
- `GET /api/orders` - Get all orders
- `GET /api/orders/:id` - Get specific order

### Payments
- `POST /api/payment/create-order` - Create Razorpay order
- `POST /api/payment/verify` - Verify payment signature

## Project Structure

```
shopdash/
├── src/
│   ├── components/
│   │   ├── DashboardLayout.jsx
│   │   ├── CardItem.jsx
│   │   ├── Cart.jsx
│   │   └── OrderSummary.jsx
│   ├── services/
│   │   └── api.js
│   ├── types/
│   │   └── index.js
│   └── App.jsx
├── backend/
│   ├── server.js
│   ├── package.json
│   └── .env.example
└── README.md
```

## Database Schema

### Product Schema
```javascript
{
  title: String,
  description: String,
  price: Number,
  image: String,
  category: String,
  stock: Number,
  timestamps: true
}
```

### Order Schema
```javascript
{
  products: [{ product: Object, quantity: Number }],
  totalAmount: Number,
  paymentId: String,
  razorpayOrderId: String,
  status: String, // 'pending' | 'completed' | 'failed'
  userDetails: {
    name: String,
    email: String,
    phone: String,
    address: String
  },
  timestamps: true
}
```

## Features in Detail

### Responsive Design
- Mobile-first approach
- Collapsible sidebar for mobile
- Grid layouts that adapt to screen size
- Touch-friendly interactions

### Payment Flow
1. User selects products and proceeds to checkout
2. Order summary with user details form
3. Razorpay order creation on backend
4. Secure payment processing
5. Payment verification and order confirmation
6. Order storage in MongoDB

### Security Features
- CORS enabled for cross-origin requests
- Payment signature verification
- Input validation and sanitization
- Environment-based configuration

## Development Notes

- The app uses mock data in development mode
- Replace mock data with actual API calls in production
- Ensure MongoDB is running before starting the backend
- Configure Razorpay webhooks for production use

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details."# Shopping-Dashboard" 
