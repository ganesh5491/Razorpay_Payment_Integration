const Razorpay = require("razorpay");

const initializeRazorpay = async () => {
  try {
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
      throw new Error("Razorpay credentials missing in environment variables");
    }

    const razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });

    // Test connection with timeout
    await Promise.race([
      razorpay.orders.all({ count: 1 }),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Razorpay connection timeout")), 5000)
      ),
    ]);

    console.log("✅ Razorpay connection verified");
    return razorpay;
  } catch (error) {
    console.error("❌ Razorpay initialization failed:", error.message);
    process.exit(1);
  }
};

module.exports = initializeRazorpay;
