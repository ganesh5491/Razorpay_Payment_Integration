const Order = require("../models/Order");
const Product = require("../models/Product");

exports.createOrder = async (req, res) => {
  try {
    const { products, userDetails, razorpayOrderId } = req.body;

    // Validate products
    if (!products || !Array.isArray(products) || products.length === 0) {
      return res.status(400).json({ error: "Products are required" });
    }

    // Calculate total amount and validate products
    let totalAmount = 0;
    const productIds = products.map((p) => p.product);
    const dbProducts = await Product.find({ _id: { $in: productIds } });

    if (dbProducts.length !== products.length) {
      return res.status(400).json({ error: "Some products not found" });
    }

    // Calculate total and validate stock
    for (const item of products) {
      const product = dbProducts.find((p) => p._id.equals(item.product));
      if (!product) {
        return res
          .status(400)
          .json({ error: `Product ${item.product} not found` });
      }
      if (product.stock < item.quantity) {
        return res
          .status(400)
          .json({ error: `Insufficient stock for ${product.title}` });
      }
      totalAmount += product.price * item.quantity;
    }

    // Create order
    const order = new Order({
      products: products.map((item) => ({
        product: item.product,
        quantity: item.quantity,
      })),
      totalAmount,
      razorpayOrderId,
      userDetails,
    });

    await order.save();

    // Update product stocks
    for (const item of products) {
      await Product.findByIdAndUpdate(item.product, {
        $inc: { stock: -item.quantity },
      });
    }

    res.status(201).json(order);
  } catch (error) {
    console.error("Error creating order:", error);
    if (error.name === "ValidationError") {
      return res
        .status(400)
        .json({ error: "Validation failed", details: error.errors });
    }
    res
      .status(500)
      .json({ error: "Failed to create order", details: error.message });
  }
};

// Other controller methods...
exports.getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find()
      .populate("products.product")
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    console.error("Error fetching orders:", error);
    res
      .status(500)
      .json({ error: "Failed to fetch orders", details: error.message });
  }
};

exports.getOrderById = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate(
      "products.product"
    );
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    res.json(order);
  } catch (error) {
    console.error("Error fetching order:", error);
    res
      .status(500)
      .json({ error: "Failed to fetch order", details: error.message });
  }
};
