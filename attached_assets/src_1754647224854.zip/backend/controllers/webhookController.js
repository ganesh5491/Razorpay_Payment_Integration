const crypto = require("crypto");
const Order = require("../models/Order");

exports.handleWebhook = async (req, res) => {
  const signature = req.headers["x-razorpay-signature"];
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;

  // Verify webhook signature
  const generatedSignature = crypto
    .createHmac("sha256", webhookSecret)
    .update(JSON.stringify(req.body))
    .digest("hex");

  if (generatedSignature !== signature) {
    return res.status(400).json({ error: "Invalid webhook signature" });
  }

  const { event, payload } = req.body;

  try {
    switch (event) {
      case "payment.captured":
        await Order.findOneAndUpdate(
          { paymentId: payload.payment.entity.id },
          {
            status: "completed",
            paymentDetails: payload.payment.entity,
            $unset: { razorpayOrderId: 1 },
          }
        );
        break;

      case "payment.failed":
        await Order.findOneAndUpdate(
          { paymentId: payload.payment.entity.id },
          {
            status: "failed",
            paymentDetails: payload.payment.entity,
            $unset: { razorpayOrderId: 1 },
          }
        );
        break;

      // Add more event handlers as needed
    }

    res.json({ success: true });
  } catch (error) {
    console.error("Webhook processing error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
};
