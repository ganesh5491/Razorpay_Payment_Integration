// const crypto = require("crypto");
// const Order = require("../models/Order");
// const razorpay = require("../config/razorpay");

// exports.createOrder = async (req, res) => {
//   try {
//     const { amount, currency = "INR", receipt } = req.body;

//     if (!amount || isNaN(amount) || amount <= 0) {
//       return res.status(400).json({
//         error: "Invalid amount",
//         details: "Amount must be a positive number",
//       });
//     }

//     const options = {
//       amount: Math.round(amount * 100),
//       currency: currency.toUpperCase(),
//       receipt: receipt || `order_${Date.now()}`,
//       payment_capture: 1,
//     };

//     const order = await razorpay.orders.create(options);

//     res.json({
//       id: order.id,
//       currency: order.currency,
//       amount: order.amount,
//       status: order.status,
//       receipt: order.receipt,
//       createdAt: order.created_at,
//     });
//   } catch (error) {
//     console.error("Error creating Razorpay order:", error);
//     res.status(500).json({
//       error: "Failed to create order",
//       details: error.error?.description || error.message,
//     });
//   }
// };

// exports.verifyPayment = async (req, res) => {
//   try {
//     const {
//       razorpay_order_id,
//       razorpay_payment_id,
//       razorpay_signature,
//       orderId,
//     } = req.body;

//     if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
//       return res
//         .status(400)
//         .json({ error: "Missing required payment details" });
//     }

//     const generatedSignature = crypto
//       .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
//       .update(`${razorpay_order_id}|${razorpay_payment_id}`)
//       .digest("hex");

//     if (generatedSignature !== razorpay_signature) {
//       return res.status(400).json({ error: "Invalid payment signature" });
//     }

//     const payment = await razorpay.payments.fetch(razorpay_payment_id);
//     const updatedOrder = await Order.findByIdAndUpdate(
//       orderId,
//       {
//         status: "completed",
//         paymentId: razorpay_payment_id,
//         paymentDetails: payment,
//         $unset: { razorpayOrderId: 1 },
//       },
//       { new: true }
//     );

//     if (!updatedOrder) {
//       return res.status(404).json({ error: "Order not found" });
//     }

//     res.json({
//       success: true,
//       message: "Payment verified successfully",
//       order: updatedOrder,
//     });
//   } catch (error) {
//     console.error("Error verifying payment:", error);
//     res.status(500).json({
//       error: "Payment verification failed",
//       details: error.message,
//     });
//   }
// };
const crypto = require("crypto");
const Order = require("../models/Order");
const razorpay = require("../config/razorpay");

exports.createOrder = async (req, res) => {
  try {
    const { amount, currency = "INR", receipt, payment_method } = req.body;

    if (!amount || isNaN(amount) || amount <= 0) {
      return res.status(400).json({
        error: "Invalid amount",
        details: "Amount must be a positive number",
      });
    }

    const options = {
      amount: Math.round(amount * 100), // Convert to paise
      currency: currency.toUpperCase(),
      receipt: receipt || `order_${Date.now()}`,
      payment_capture: 1, // Auto-capture payment
    };

    // Add payment method specific options
    if (payment_method) {
      options.method = payment_method;

      // For UPI payments
      if (payment_method === "upi") {
        options.upi = {
          flow: "collect", // or "intent" for UPI apps
        };
      }

      // For card payments
      if (payment_method === "card") {
        options.card = {
          network: req.body.card_network || null, // visa/mastercard/etc
          name: req.body.card_name || null,
        };
      }

      // For wallet payments
      if (payment_method === "wallet") {
        options.wallet = req.body.wallet_name || null; // paytm/amazonpay/etc
      }

      // For netbanking
      if (payment_method === "netbanking") {
        options.bank = req.body.bank_code || null; // HDFC/ICICI/etc
      }
    }

    const order = await razorpay.orders.create(options);

    res.json({
      id: order.id,
      currency: order.currency,
      amount: order.amount,
      status: order.status,
      receipt: order.receipt,
      createdAt: order.created_at,
      method: payment_method || "all",
    });
  } catch (error) {
    console.error("Error creating Razorpay order:", error);
    res.status(500).json({
      error: "Failed to create order",
      details: error.error?.description || error.message,
    });
  }
};

exports.verifyPayment = async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      orderId,
      payment_method,
    } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res
        .status(400)
        .json({ error: "Missing required payment details" });
    }

    // Verify signature
    const generatedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");

    if (generatedSignature !== razorpay_signature) {
      return res.status(400).json({ error: "Invalid payment signature" });
    }

    // Fetch payment details
    const payment = await razorpay.payments.fetch(razorpay_payment_id);

    // Update order status
    const updateData = {
      status: "completed",
      paymentId: razorpay_payment_id,
      paymentDetails: payment,
      paymentMethod: payment_method || payment.method,
      $unset: { razorpayOrderId: 1 },
    };

    const updatedOrder = await Order.findByIdAndUpdate(orderId, updateData, {
      new: true,
    });

    if (!updatedOrder) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({
      success: true,
      message: "Payment verified successfully",
      order: updatedOrder,
    });
  } catch (error) {
    console.error("Error verifying payment:", error);
    res.status(500).json({
      error: "Payment verification failed",
      details: error.message,
    });
  }
};

exports.createCodOrder = async (req, res) => {
  try {
    const { orderId } = req.body;

    const updatedOrder = await Order.findByIdAndUpdate(
      orderId,
      {
        status: "confirmed",
        paymentMethod: "cod",
        $unset: { razorpayOrderId: 1 },
      },
      { new: true }
    );

    if (!updatedOrder) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({
      success: true,
      message: "COD order confirmed",
      order: updatedOrder,
    });
  } catch (error) {
    console.error("Error creating COD order:", error);
    res.status(500).json({
      error: "Failed to create COD order",
      details: error.message,
    });
  }
};