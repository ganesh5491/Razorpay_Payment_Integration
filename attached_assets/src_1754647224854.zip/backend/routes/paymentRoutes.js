const express = require("express");
const router = express.Router();
const paymentController = require("../controllers/paymentController");
const { protect } = require("../middlewares/authMiddleware");
const webhookController = require("../controllers/webhookController");
// Regular payment routes
router.post("/create-order", protect, paymentController.createOrder);
router.post("/verify", protect, paymentController.verifyPayment);
router.post(
  "/webhook",
  express.raw({ type: "application/json" }),
  webhookController.handleWebhook
);
// COD specific route
router.post("/cod", protect, paymentController.createCodOrder);

// Get payment methods
router.get("/methods", protect, async (req, res) => {
  try {
    const methods = {
      upi: {
        name: "UPI",
        description: "Pay via UPI ID or QR Code",
        icon: "💳",
        banks: ["any"],
      },
      card: {
        name: "Credit/Debit Card",
        description: "Pay using Visa, Mastercard, etc.",
        icon: "🪪",
        networks: ["visa", "mastercard", "rupay", "amex"],
      },
      netbanking: {
        name: "Net Banking",
        description: "Pay directly via your bank",
        icon: "🏦",
        banks: [
          { code: "HDFC", name: "HDFC Bank" },
          { code: "ICICI", name: "ICICI Bank" },
          { code: "SBI", name: "State Bank of India" },
          { code: "AXIS", name: "Axis Bank" },
        ],
      },
      wallet: {
        name: "Wallet",
        description: "Pay via digital wallets",
        icon: "💰",
        wallets: [
          { code: "paytm", name: "Paytm" },
          { code: "amazonpay", name: "Amazon Pay" },
          { code: "phonepe", name: "PhonePe" },
          { code: "mobikwik", name: "MobiKwik" },
        ],
      },
      cod: {
        name: "Cash on Delivery",
        description: "Pay when you receive the order",
        icon: "💵",
        extra_charge: 50,
      },
    };

    res.json(methods);
  } catch (error) {
    console.error("Error fetching payment methods:", error);
    res.status(500).json({ error: "Failed to fetch payment methods" });
  }
});

module.exports = router;
