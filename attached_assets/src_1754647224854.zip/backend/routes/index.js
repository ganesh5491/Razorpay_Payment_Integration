const express = require("express");
const router = express.Router();

const productRoutes = require("./productRoutes");
const orderRoutes = require("./orderRoutes");
const paymentRoutes = require("./paymentRoutes"); // Add this line

// Health check endpoint
router.get("/health", (req, res) => {
  res.json({
    status: "OK",
    message: "Server is running",
    uptime: process.uptime(),
  });
});

// API routes
router.use("/products", productRoutes);
router.use("/orders", orderRoutes);
router.use("/payment", paymentRoutes); // Add this line

// Root endpoint
router.get("/", (req, res) => {
  res.json({
    message: "ShopDash Backend API",
    version: "1.0.0",
    endpoints: {
      products: {
        GET: "/api/products",
        POST: "/api/products",
      },
      orders: {
        GET: "/api/orders",
        POST: "/api/orders",
        GET_ONE: "/api/orders/:id",
      },
      payment: {
        POST: "/api/payment/create-order",
        POST: "/api/payment/verify",
      },
      health: {
        GET: "/api/health",
      },
    },
  });
});

module.exports = router;
