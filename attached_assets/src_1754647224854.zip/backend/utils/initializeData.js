const Product = require("../models/Product");

const mockProducts = [
  {
    title: "Wireless Headphones",
    description: "High-quality wireless headphones with noise cancellation",
    price: 2999,
    image: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg",
    category: "Electronics",
    stock: 15,
  },
  {
    title: "Smart Watch",
    description: "Feature-rich smartwatch with health monitoring",
    price: 8999,
    image: "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg",
    category: "Electronics",
    stock: 8,
  },
  {
    title: "Laptop Backpack",
    description: "Durable laptop backpack with multiple compartments",
    price: 1599,
    image: "https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg",
    category: "Accessories",
    stock: 20,
  },
];

async function initializeProducts() {
  try {
    const count = await Product.countDocuments();
    if (count === 0) {
      await Product.insertMany(mockProducts);
      console.log("📦 Mock products inserted");
    }
  } catch (error) {
    console.error("❌ Failed to initialize products:", error);
  }
}

module.exports = initializeProducts;
