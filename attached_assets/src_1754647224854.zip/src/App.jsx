import React, { useState } from "react";
import { Toaster, toast } from "react-hot-toast";
import DashboardLayout from "./components/DashboardLayout";
import CardItem from "./components/CardItem";
import Cart from "./components/Cart";
import OrderSummary from "./components/OrderSummary";
import useCart from "./hooks/useCart";
import useProducts from "./hooks/useProducts";
import usePayment from "./hooks/usePayment";

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isOrderSummaryOpen, setIsOrderSummaryOpen] = useState(false);

  const { products } = useProducts();
  const {
    cartItems,
    cartItemsCount,
    addToCart,
    updateQuantity,
    removeFromCart,
    setCartItems,
  } = useCart();

  const { handlePlaceOrder, isLoading } = usePayment();

  const handleBuyNow = (product) => {
    setCartItems([{ product, quantity: 1 }]);
    setIsOrderSummaryOpen(true);
    toast.success("Proceeding to checkout");
  };

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast.error("Cart is empty");
      return;
    }
    setIsCartOpen(false);
    setIsOrderSummaryOpen(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: "#363636",
            color: "#fff",
          },
        }}
      />
      <DashboardLayout
        cartItemsCount={cartItemsCount}
        onCartClick={() => setIsCartOpen(true)}
      >
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">
              Featured Products
            </h2>
            <p className="text-gray-600">
              {products.length} products available
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <CardItem
                key={product._id}
                product={product}
                onAddToCart={addToCart}
                onBuyNow={handleBuyNow}
              />
            ))}
          </div>
        </div>
      </DashboardLayout>
      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeFromCart}
        onCheckout={handleCheckout}
      />
      // App.jsx
      <OrderSummary
        isOpen={isOrderSummaryOpen}
        onClose={() => setIsOrderSummaryOpen(false)}
        cartItems={cartItems}
        onPlaceOrder={(userDetails) => handlePlaceOrder(cartItems, userDetails)}
        isLoading={isLoading}
      />
    </div>
  );
}

export default App;
