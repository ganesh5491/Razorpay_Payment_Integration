import axios from "axios";

export const initializeRazorpay = () => {
  return new Promise((resolve) => {
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => {
      resolve(true);
    };
    script.onerror = () => {
      resolve(false);
    };
    document.body.appendChild(script);
  });
};

export const getPaymentMethods = async () => {
  try {
    const response = await axios.get("/api/payment/methods");
    return response.data;
  } catch (error) {
    console.error("Error fetching payment methods:", error);
    throw error;
  }
};

export const createRazorpayOrder = async (
  amount,
  paymentMethod,
  methodDetails = {}
) => {
  try {
    const response = await axios.post("/api/payment/create-order", {
      amount,
      payment_method: paymentMethod,
      ...methodDetails,
    });
    return response.data;
  } catch (error) {
    console.error("Error creating Razorpay order:", error);
    throw error;
  }
};

export const verifyPayment = async (
  paymentResponse,
  orderId,
  paymentMethod
) => {
  try {
    const response = await axios.post("/api/payment/verify", {
      razorpay_order_id: paymentResponse.razorpay_order_id,
      razorpay_payment_id: paymentResponse.razorpay_payment_id,
      razorpay_signature: paymentResponse.razorpay_signature,
      orderId,
      payment_method: paymentMethod,
    });
    return response.data;
  } catch (error) {
    console.error("Error verifying payment:", error);
    throw error;
  }
};

export const createCodOrder = async (orderId) => {
  try {
    const response = await axios.post("/api/payment/cod", { orderId });
    return response.data;
  } catch (error) {
    console.error("Error creating COD order:", error);
    throw error;
  }
};

export const makePayment = async (paymentDetails) => {
  const res = await initializeRazorpay();
  if (!res) {
    throw new Error("Razorpay SDK failed to load");
  }

  const options = {
    key: process.env.RAZORPAY_KEY_ID,
    amount: paymentDetails.amount * 100,
    currency: "INR",
    name: "Your Store Name",
    description: "Payment for your order",
    order_id: paymentDetails.orderId,
    handler: function (response) {
      return response;
    },
    prefill: {
      name: paymentDetails.name,
      email: paymentDetails.email,
      contact: paymentDetails.phone,
    },
    notes: {
      address: paymentDetails.address,
      orderId: paymentDetails.internalOrderId,
    },
    theme: {
      color: "#3399cc",
    },
    method: paymentDetails.method,
    ...(paymentDetails.method === "upi" && {
      upi: {
        flow: paymentDetails.upiFlow || "collect", // 'collect' or 'intent'
        vpa: paymentDetails.upiId || null,
      },
    }),
    ...(paymentDetails.method === "card" && {
      card: {
        network: paymentDetails.cardNetwork || null,
        name: paymentDetails.cardName || null,
      },
    }),
    ...(paymentDetails.method === "netbanking" && {
      bank: paymentDetails.bankCode || null,
    }),
    ...(paymentDetails.method === "wallet" && {
      wallet: paymentDetails.walletName || null,
    }),
  };

  const rzp = new window.Razorpay(options);
  rzp.open();
};
