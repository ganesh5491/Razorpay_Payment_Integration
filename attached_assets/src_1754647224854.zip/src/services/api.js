// REAL Razorpay order creation
export const createPaymentOrder = async (amount) => {
  try {
    const response = await api.post("/payment/create-order", {
      amount,
      currency: "INR",
    });
    return response.data;
  } catch (error) {
    console.error("API Error - createPaymentOrder:", error);
    throw error;
  }
};

// REAL Razorpay payment verification

export const verifyPayment = async (paymentData) => {
  try {
    const response = await api.post("/payment/verify", paymentData);
    return response.data;
  } catch (error) {
    console.error("API Error - verifyPayment:", error);
    throw error;
  }
};

// REAL order creation
export const createOrder = async (orderData) => {
  try {
    const response = await api.post("/order", orderData);
    return response.data;
  } catch (error) {
    console.error("Error creating order:", error);
    throw error;
  }
};

import axios from "axios";

const API_BASE_URL = "http://localhost:5000/api";

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Products API
export const fetchProducts = async () => {
  try {
    const response = await api.get("/products");
    return response.data;
  } catch (error) {
    console.error("Error fetching products:", error);
    throw error;
  }
};

// ...existing code...
