export { default as UpiPayment } from "./UpiPayment";
export { default as CardPayment } from "./CardPayment";
export { default as NetBankingPayment } from "./NetBankingPayment";
export { default as WalletPayment } from "./WalletPayment";
export { default as CodPayment } from "./CodPayment";

export const ProductSchema = {
  _id: "",
  title: "",
  description: "",
  price: 0,
  image: "",
  category: "",
  stock: 0,
};

export const CartItemSchema = {
  product: ProductSchema,
  quantity: 0,
};

export const OrderSchema = {
  _id: "",
  products: [],
  totalAmount: 0,
  paymentId: "",
  razorpayOrderId: "",
  status: "pending", // 'pending' | 'completed' | 'failed'
  createdAt: "",
  userDetails: {
    name: "",
    email: "",
    phone: "",
    address: "",
  },
};
