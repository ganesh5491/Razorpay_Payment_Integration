import React, { useState } from "react";
import axios from "axios";

const PaymentForm = () => {
  const [totalAmount, setTotalAmount] = useState(1000); // Example amount in paise (₹10.00)
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const createPaymentOrder = async (amount) => {
    try {
      const response = await axios.post("/api/payment/create-order", {
        amount: amount,
        currency: "INR",
      });
      return response.data;
    } catch (error) {
      console.error("Error creating payment order:", error);
      throw error;
    }
  };

  const handlePayment = async () => {
    setLoading(true);
    setError(null);

    try {
      // 1. Load Razorpay script
      const isScriptLoaded = await loadRazorpayScript();
      if (!isScriptLoaded) {
        throw new Error("Razorpay SDK failed to load");
      }

      // 2. Create order on backend
      const orderData = await createPaymentOrder(totalAmount);

      // 3. Initialize Razorpay payment
      const options = {
        key: process.env.REACT_APP_RAZORPAY_KEY_ID, // Your Razorpay key
        amount: orderData.amount,
        currency: orderData.currency,
        order_id: orderData.id,
        name: "Your Company Name",
        description: "Payment for Order",
        handler: async function (response) {
          try {
            // 4. Verify payment on backend
            await axios.post("/api/payment/verify", {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              orderId: orderData.id, // Your database order ID if needed
            });

            // Payment successful
            alert("Payment Successful!");
          } catch (verificationError) {
            console.error("Payment verification failed:", verificationError);
            alert("Payment verification failed");
          }
        },
        prefill: {
          name: "Customer Name",
          email: "customer@example.com",
          contact: "9999999999",
        },
        theme: {
          color: "#3399cc",
        },
        modal: {
          ondismiss: function () {
            alert("Payment window closed");
          },
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (error) {
      console.error("Payment error:", error);
      setError(error.message || "Payment failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="payment-form">
      <h2>Payment Details</h2>

      <div className="form-group">
        <label>Amount (in INR):</label>
        <input
          type="number"
          value={totalAmount / 100}
          onChange={(e) => setTotalAmount(Math.round(e.target.value * 100))}
          min="1"
          step="0.01"
        />
      </div>

      {error && <div className="error-message">{error}</div>}

      <button onClick={handlePayment} disabled={loading} className="pay-button">
        {loading ? "Processing..." : `Pay ₹${(totalAmount / 100).toFixed(2)}`}
      </button>

      <style jsx>{`
        .payment-form {
          max-width: 400px;
          margin: 0 auto;
          padding: 20px;
          border: 1px solid #ddd;
          border-radius: 8px;
        }
        .form-group {
          margin-bottom: 15px;
        }
        label {
          display: block;
          margin-bottom: 5px;
          font-weight: bold;
        }
        input {
          width: 100%;
          padding: 8px;
          border: 1px solid #ddd;
          border-radius: 4px;
        }
        .pay-button {
          background-color: #3399cc;
          color: white;
          border: none;
          padding: 10px 15px;
          border-radius: 4px;
          cursor: pointer;
          width: 100%;
        }
        .pay-button:disabled {
          background-color: #cccccc;
          cursor: not-allowed;
        }
        .error-message {
          color: red;
          margin-bottom: 15px;
        }
      `}</style>
    </div>
  );
};

export default PaymentForm;

// import React, { useState } from "react";
// import { makePayment } from "../services/paymentService";
// import {
//   UpiPayment,
//   CardPayment,
//   NetBankingPayment,
//   WalletPayment,
//   CodPayment,
// } from "./payment-methods";

// const PaymentForm = ({
//   amount,
//   userDetails,
//   orderId,
//   onPaymentSuccess,
//   onPaymentError,
// }) => {
//   const [activeMethod, setActiveMethod] = useState("upi");
//   const [error, setError] = useState("");

//   const handlePaymentSuccess = async (paymentData) => {
//     try {
//       if (paymentData.method === "cod") {
//         // Handle COD separately
//         onPaymentSuccess({ method: "cod" });
//         return;
//       }

//       // For other payment methods, initiate Razorpay
//       const paymentDetails = {
//         ...userDetails,
//         amount,
//         orderId,
//         ...paymentData,
//       };

//       const response = await makePayment(paymentDetails);
//       onPaymentSuccess(response);
//     } catch (err) {
//       setError(err.message);
//       onPaymentError(err);
//     }
//   };

//   const renderPaymentMethod = () => {
//     switch (activeMethod) {
//       case "upi":
//         return (
//           <UpiPayment onSuccess={handlePaymentSuccess} onError={setError} />
//         );
//       case "card":
//         return (
//           <CardPayment onSuccess={handlePaymentSuccess} onError={setError} />
//         );
//       case "netbanking":
//         return (
//           <NetBankingPayment
//             onSuccess={handlePaymentSuccess}
//             onError={setError}
//           />
//         );
//       case "wallet":
//         return (
//           <WalletPayment onSuccess={handlePaymentSuccess} onError={setError} />
//         );
//       case "cod":
//         return <CodPayment onSuccess={handlePaymentSuccess} />;
//       default:
//         return null;
//     }
//   };

//   return (
//     <div className="space-y-6">
//       <div className="grid grid-cols-5 gap-2">
//         <button
//           onClick={() => setActiveMethod("upi")}
//           className={`p-3 border rounded-md flex flex-col items-center ${
//             activeMethod === "upi"
//               ? "border-blue-500 bg-blue-50"
//               : "border-gray-300"
//           }`}
//         >
//           <span className="text-2xl">💳</span>
//           <span className="text-xs mt-1">UPI</span>
//         </button>
//         <button
//           onClick={() => setActiveMethod("card")}
//           className={`p-3 border rounded-md flex flex-col items-center ${
//             activeMethod === "card"
//               ? "border-blue-500 bg-blue-50"
//               : "border-gray-300"
//           }`}
//         >
//           <span className="text-2xl">🪪</span>
//           <span className="text-xs mt-1">Card</span>
//         </button>
//         <button
//           onClick={() => setActiveMethod("netbanking")}
//           className={`p-3 border rounded-md flex flex-col items-center ${
//             activeMethod === "netbanking"
//               ? "border-blue-500 bg-blue-50"
//               : "border-gray-300"
//           }`}
//         >
//           <span className="text-2xl">🏦</span>
//           <span className="text-xs mt-1">Net Banking</span>
//         </button>
//         <button
//           onClick={() => setActiveMethod("wallet")}
//           className={`p-3 border rounded-md flex flex-col items-center ${
//             activeMethod === "wallet"
//               ? "border-blue-500 bg-blue-50"
//               : "border-gray-300"
//           }`}
//         >
//           <span className="text-2xl">💰</span>
//           <span className="text-xs mt-1">Wallet</span>
//         </button>
//         <button
//           onClick={() => setActiveMethod("cod")}
//           className={`p-3 border rounded-md flex flex-col items-center ${
//             activeMethod === "cod"
//               ? "border-blue-500 bg-blue-50"
//               : "border-gray-300"
//           }`}
//         >
//           <span className="text-2xl">💵</span>
//           <span className="text-xs mt-1">COD</span>
//         </button>
//       </div>

//       {error && (
//         <div className="bg-red-50 border-l-4 border-red-500 p-4">
//           <div className="flex">
//             <div className="flex-shrink-0">
//               <X className="h-5 w-5 text-red-500" />
//             </div>
//             <div className="ml-3">
//               <p className="text-sm text-red-700">{error}</p>
//             </div>
//           </div>
//         </div>
//       )}

//       <div className="bg-white p-6 rounded-lg shadow-sm">
//         {renderPaymentMethod()}
//       </div>
//     </div>
//   );
// };

// export default PaymentForm;