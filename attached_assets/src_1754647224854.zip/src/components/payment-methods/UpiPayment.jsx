import React, { useState } from "react";
import { Check, X } from "lucide-react";
import { makePayment, verifyPayment } from "../../services/paymentService";

const UpiPayment = ({ amount, userDetails, orderId, onSuccess, onError }) => {
  const [upiId, setUpiId] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handlePayment = async () => {
    try {
      setIsLoading(true);

      // Create Razorpay order
      const order = await createRazorpayOrder(amount, "upi", { upiId });

      // Initiate payment
      const paymentResponse = await makePayment({
        ...userDetails,
        amount,
        orderId: order.id,
        internalOrderId: orderId,
        method: "upi",
        upiId,
        upiFlow: "collect", // or 'intent' for UPI apps
      });

      // Verify payment
      const verification = await verifyPayment(paymentResponse, orderId, "upi");

      onSuccess(verification);
    } catch (error) {
      onError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerify = () => {
    if (upiId.includes("@") && upiId.length > 5) {
      setIsVerified(true);
    } else {
      onError("Please enter a valid UPI ID");
    }
  };

  return (
    <div className="space-y-4">
      {/* ... existing UI code ... */}
      <button
        onClick={handlePayment}
        disabled={!isVerified || isLoading}
        className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
      >
        {isLoading ? "Processing..." : `Pay ₹${amount}`}
      </button>
    </div>
  );
};

export default UpiPayment;
