import React, { useState } from "react";
import { Banknote } from "lucide-react";

const banks = [
  { id: "SBI", name: "State Bank of India" },
  { id: "HDFC", name: "HDFC Bank" },
  { id: "ICICI", name: "ICICI Bank" },
  { id: "AXIS", name: "Axis Bank" },
  { id: "KOTAK", name: "Kotak Mahindra Bank" },
];

const NetBankingPayment = ({ onSuccess, onError }) => {
  const [selectedBank, setSelectedBank] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedBank) {
      onError("Please select a bank");
      return;
    }
    onSuccess({ method: "netbanking", bank: selectedBank });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <span className="text-2xl">🏦</span>
        <h3 className="text-lg font-medium">Net Banking</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700">
            Select Bank
          </label>
          <select
            value={selectedBank}
            onChange={(e) => setSelectedBank(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Select your bank</option>
            {banks.map((bank) => (
              <option key={bank.id} value={bank.id}>
                {bank.name}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Pay ₹{amount}
        </button>
      </form>
    </div>
  );
};

export default NetBankingPayment;
