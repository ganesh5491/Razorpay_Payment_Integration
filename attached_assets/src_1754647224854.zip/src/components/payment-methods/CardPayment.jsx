import React, { useState } from "react";
import { CreditCard } from "lucide-react";

const CardPayment = ({ onSuccess, onError }) => {
  const [cardDetails, setCardDetails] = useState({
    number: "",
    name: "",
    expiry: "",
    cvv: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCardDetails((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Basic validation
    if (cardDetails.number.length !== 16) {
      onError("Please enter a valid 16-digit card number");
      return;
    }
    if (cardDetails.cvv.length !== 3) {
      onError("Please enter a valid CVV");
      return;
    }
    onSuccess({ method: "card", ...cardDetails });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <span className="text-2xl">🪪</span>
        <h3 className="text-lg font-medium">Credit/Debit Card</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Card Number
          </label>
          <input
            type="text"
            name="number"
            value={cardDetails.number}
            onChange={handleChange}
            placeholder="1234 5678 9012 3456"
            maxLength="16"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Cardholder Name
          </label>
          <input
            type="text"
            name="name"
            value={cardDetails.name}
            onChange={handleChange}
            placeholder="Name on card"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Expiry (MM/YY)
            </label>
            <input
              type="text"
              name="expiry"
              value={cardDetails.expiry}
              onChange={handleChange}
              placeholder="MM/YY"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              CVV
            </label>
            <input
              type="text"
              name="cvv"
              value={cardDetails.cvv}
              onChange={handleChange}
              placeholder="123"
              maxLength="3"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Pay ₹{amount}
        </button>
      </form>
    </div>
  );
};

export default CardPayment;
