import React from "react";
import { Package } from "lucide-react";

const CodPayment = ({ onSuccess }) => {
  const handleConfirm = () => {
    onSuccess({ method: "cod" });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <span className="text-2xl">💵</span>
        <h3 className="text-lg font-medium">Cash on Delivery</h3>
      </div>

      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <Package className="h-5 w-5 text-yellow-400" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-yellow-700">
              Pay cash when your order is delivered. An extra ₹50 charge may
              apply.
            </p>
          </div>
        </div>
      </div>

      <button
        onClick={handleConfirm}
        className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
      >
        Confirm Order
      </button>
    </div>
  );
};

export default CodPayment;
