import React, { useState } from "react";
import { Wallet } from "lucide-react";

const wallets = [
  { id: "paytm", name: "Paytm", icon: "P" },
  { id: "phonepe", name: "PhonePe", icon: "P" },
  { id: "amazonpay", name: "Amazon Pay", icon: "A" },
  { id: "mobikwik", name: "MobiKwik", icon: "M" },
];

const WalletPayment = ({ onSuccess, onError }) => {
  const [selectedWallet, setSelectedWallet] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedWallet) {
      onError("Please select a wallet");
      return;
    }
    onSuccess({ method: "wallet", wallet: selectedWallet });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <span className="text-2xl">💰</span>
        <h3 className="text-lg font-medium">Wallet</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          {wallets.map((wallet) => (
            <div
              key={wallet.id}
              onClick={() => setSelectedWallet(wallet.id)}
              className={`p-3 border rounded-md cursor-pointer flex items-center space-x-2 ${
                selectedWallet === wallet.id
                  ? "border-blue-500 bg-blue-50"
                  : "border-gray-300"
              }`}
            >
              <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                {wallet.icon}
              </div>
              <span>{wallet.name}</span>
            </div>
          ))}
        </div>

        <button
          type="submit"
          className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Pay ₹{amount}
        </button>
      </form>
    </div>
  );
};

export default WalletPayment;
