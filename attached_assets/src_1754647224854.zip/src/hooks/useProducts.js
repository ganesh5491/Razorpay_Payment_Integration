import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { fetchProducts } from '../services/api';

const mockProducts = [
  {
    _id: "1",
    title: "Premium Wireless Headphones",
    description:
      "High-quality wireless headphones with noise cancellation and superior sound quality.",
    price: 2999,
    image:
      "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Electronics",
    stock: 15,
  },
  {
    _id: "2",
    title: "Smart Fitness Watch",
    description:
      "Advanced fitness tracker with heart rate monitoring, GPS, and water resistance.",
    price: 4999,
    image:
      "https://images.pexels.com/photos/1772123/pexels-photo-1772123.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Wearables",
    stock: 8,
  },
  {
    _id: "3",
    title: "Portable Bluetooth Speaker",
    description:
      "Compact wireless speaker with powerful bass and 12-hour battery life.",
    price: 1999,
    image:
      "https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Electronics",
    stock: 25,
  },
  {
    _id: "4",
    title: "Professional Camera Lens",
    description: "50mm f/1.8 prime lens perfect for portrait photography.",
    price: 8999,
    image:
      "https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Photography",
    stock: 5,
  },
  {
    _id: "5",
    title: "Ergonomic Office Chair",
    description:
      "Comfortable office chair with lumbar support and adjustable height.",
    price: 7999,
    image:
      "https://images.pexels.com/photos/586958/pexels-photo-586958.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Furniture",
    stock: 12,
  },
  {
    _id: "6",
    title: "Mechanical Gaming Keyboard",
    description:
      "RGB backlit mechanical keyboard with customizable keys and switches.",
    price: 3999,
    image:
      "https://images.pexels.com/photos/2115217/pexels-photo-2115217.jpeg?auto=compress&cs=tinysrgb&w=500",
    category: "Gaming",
    stock: 20,
  },
];
export default function useProducts() {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadProducts = async () => {
    try {
      setIsLoading(true);
      // In production: const data = await fetchProducts();
      setProducts(mockProducts);
      toast.success('Products loaded successfully!');
    } catch (error) {
      console.error('Error loading products:', error);
      toast.error('Failed to load products');
      setProducts(mockProducts);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  return { products, isLoading };
}