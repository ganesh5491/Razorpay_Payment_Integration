// OrderSummary.jsx
const handleSubmit = (userDetails) => {
  onPlaceOrder(cartItems, userDetails); // Make sure cartItems is passed correctly
};
