import { useState } from "react";
import { toast } from "react-hot-toast";
import {
  createPaymentOrder,
  verifyPayment,
  createOrder,
} from "../services/api";

export default function usePayment() {
  const [isLoading, setIsLoading] = useState(false);
  const [paymentError, setPaymentError] = useState(null);

  const initializeRazorpay = () => {
    return new Promise((resolve) => {
      // Check if Razorpay is already loaded
      if (window.Razorpay) {
        return resolve(true);
      }

      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.async = true;
      script.id = "razorpay-script";

      script.onload = () => {
        console.log("Razorpay SDK loaded successfully");
        resolve(true);
      };

      script.onerror = () => {
        console.error("Failed to load Razorpay SDK");
        document.getElementById("razorpay-script")?.remove();
        resolve(false);
      };

      document.body.appendChild(script);
    });
  };

  const validateCartItems = (cartItems) => {
    if (!Array.isArray(cartItems)) {
      throw new Error("Invalid cart items format");
    }

    if (cartItems.length === 0) {
      throw new Error("Your cart is empty");
    }

    cartItems.forEach((item, index) => {
      if (!item.product || typeof item.product !== "object") {
        throw new Error(`Invalid product at position ${index}`);
      }
      if (typeof item.quantity !== "number" || item.quantity < 1) {
        throw new Error(`Invalid quantity for product ${item.product._id}`);
      }
      if (typeof item.product.price !== "number" || item.product.price <= 0) {
        throw new Error(`Invalid price for product ${item.product._id}`);
      }
    });
  };

  const calculateTotal = (cartItems) => {
    return cartItems.reduce((total, item) => {
      return total + item.product.price * item.quantity;
    }, 0);
  };

  const handlePaymentSuccess = async (
    response,
    cartItems,
    total,
    userDetails
  ) => {
    try {
      // Verify payment with backend
      await verifyPayment({
        razorpay_order_id: response.razorpay_order_id,
        razorpay_payment_id: response.razorpay_payment_id,
        razorpay_signature: response.razorpay_signature,
      });

      // Create order record in database
      await createOrder({
        products: cartItems,
        totalAmount: total,
        paymentId: response.razorpay_payment_id,
        razorpayOrderId: response.razorpay_order_id,
        status: "completed",
        userDetails,
      });

      toast.success("Order placed successfully! 🎉");
      return true;
    } catch (error) {
      console.error("Payment verification failed:", error);
      toast.error("Payment verification failed. Please contact support.");
      return false;
    }
  };

  const handlePlaceOrder = async (cartItems, userDetails) => {
    try {
      setIsLoading(true);
      setPaymentError(null);

      // 1. Validate cart items
      validateCartItems(cartItems);

      // 2. Calculate total amount
      const total = calculateTotal(cartItems);
      console.log("Order total:", total);

      // 3. Load Razorpay SDK
      const isRazorpayLoaded = await initializeRazorpay();
      if (!isRazorpayLoaded) {
        throw new Error("Payment service is currently unavailable");
      }

      // 4. Create payment order on backend
      const orderData = await createPaymentOrder(total);
      console.log("Razorpay order created:", orderData);

      // 5. Initialize Razorpay checkout
      const options = {
        key: process.env.REACT_APP_RAZORPAY_KEY_ID || "rzp_test_Y1H7sPG80POAQz",
        amount: orderData.amount,
        currency: orderData.currency,
        name: "ShopDash",
        description: `Order #${orderData.receipt}`,
        order_id: orderData.id,
        handler: (response) =>
          handlePaymentSuccess(response, cartItems, total, userDetails),
        prefill: {
          name: userDetails.name,
          email: userDetails.email,
          contact: userDetails.phone,
        },
        notes: {
          address: userDetails.address,
          orderId: orderData.id,
        },
        theme: {
          color: "#3B82F6",
        },
        modal: {
          ondismiss: () => {
            toast("Payment window closed", { icon: "ℹ️" });
          },
        },
      };

      const razorpay = new window.Razorpay(options);

      razorpay.on("payment.failed", (response) => {
        console.error("Payment failed:", response.error);
        toast.error(`Payment failed: ${response.error.description}`);
      });

      razorpay.open();
    } catch (error) {
      console.error("Checkout error:", error);
      setPaymentError(error.message);

      if (error.response) {
        // Axios error with response
        toast.error(
          error.response.data?.message || "Payment processing failed"
        );
      } else {
        // Other errors
        toast.error(error.message || "Something went wrong during checkout");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return {
    handlePlaceOrder,
    isLoading,
    paymentError,
    resetPaymentError: () => setPaymentError(null),
  };
}
